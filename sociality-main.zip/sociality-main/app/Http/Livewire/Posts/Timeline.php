<?php

namespace App\Http\Livewire\Posts;

use Livewire\Component;

class Timeline extends Component
{
    public function render()
    {
        return view('livewire.posts.timeline');
    }
}
